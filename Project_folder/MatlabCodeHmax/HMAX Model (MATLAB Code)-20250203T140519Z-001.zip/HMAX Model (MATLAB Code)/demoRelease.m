% demoRelease.m
% demonstrates how to use C2 standard model features in a pattern classification framework
	    
READPATCHESFROMFILE = 0; %use patches that were already computed
                         %(e.g., from natural images)

patchSizes = [4 8 12 16]; %other sizes might be better, maybe not
                          %all sizes are required
			  
numPatchSizes = length(patchSizes);

%specify directories for training and testing images
train_set.pos   = 'Dataset/Train/Train_Animals';
train_set.neg   = 'Dataset/Train/Train_Non-Animals';
test_set.pos    = 'Dataset/Test/Test_Animals';
test_set.neg    = 'Dataset/Test/Test_Non-Animals';

cI = readAllImages(train_set,test_set); %cI is a cell containing
                                        %all training and testing images

if isempty(cI{1}) | isempty(cI{2})
  error(['No training images were loaded -- did you remember to' ...
	' change the path names?']);
end
  
%below the c1 prototypes are extracted from the images/ read from file
if ~READPATCHESFROMFILE
  tic
  numPatchesPerSize = 250; %more will give better results, but will
                           %take more time to compute
  cPatches = extractRandC1Patches(cI{1}, numPatchSizes, ...
      numPatchesPerSize, patchSizes); %fix: extracting from positive only 
                                      
  totaltimespectextractingPatches = toc;
else
  fprintf('reading patches');
  cPatches = load('PatchesFromNaturalImages250per4sizes','cPatches');
  cPatches = cPatches.cPatches;
end

%----Settings for Testing --------%
rot = [90 -45 0 45];
c1ScaleSS = [1:2:18];
RF_siz    = [7:2:39];
c1SpaceSS = [8:2:22];
minFS     = 7;
maxFS     = 39;
div = [4:-.05:3.2];
Div       = div;
%--- END Settings for Testing --------%

fprintf(1,'Initializing gabor filters -- full set...');
%creates the gabor filters use to extract the S1 layer
[fSiz,filters,c1OL,numSimpleFilters] = init_gabor(rot, RF_siz, Div);
fprintf(1,'done\n');

%The actual C2 features are computed below for each one of the training/testing directories
tic
for i = 1:4
  C2res{i} = extractC2forcell(filters,fSiz,c1SpaceSS,c1ScaleSS,c1OL,cPatches,cI{i},numPatchSizes);
  toc
end
totaltimespectextractingC2 = toc;

%Simple classification code
XTrain = [C2res{1} C2res{2}]; %training examples as columns 
XTest =  [C2res{3},C2res{4}]; %the labels of the training set
ytrain = [ones(size(C2res{1},2),1);-ones(size(C2res{2},2),1)]; %testing examples as columns
ytest = [ones(size(C2res{3},2),1);-ones(size(C2res{4},2),1)]; %the true labels of the test set



